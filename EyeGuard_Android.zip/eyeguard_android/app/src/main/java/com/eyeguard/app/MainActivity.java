package com.eyeguard.app;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Switch;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    private Switch switchEnable;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        switchEnable = findViewById(R.id.switchEnable);
        switchEnable.setChecked(true);

        // Khởi động service ngay khi mở app
        startService();

        switchEnable.setOnCheckedChangeListener((btn, isChecked) -> {
            if (isChecked) {
                startService();
            } else {
                stopService(new Intent(this, EyeGuardService.class));
            }
        });
    }

    private void startService() {
        Intent intent = new Intent(this, EyeGuardService.class);
        startForegroundService(intent);
    }
}
