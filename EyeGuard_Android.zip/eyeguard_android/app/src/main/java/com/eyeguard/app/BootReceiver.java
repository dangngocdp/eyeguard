package com.eyeguard.app;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;

public class BootReceiver extends BroadcastReceiver {
    @Override
    public void onReceive(Context context, Intent intent) {
        if (Intent.ACTION_BOOT_COMPLETED.equals(intent.getAction())) {
            // Tự khởi động service sau khi điện thoại bật lên
            Intent serviceIntent = new Intent(context, EyeGuardService.class);
            context.startForegroundService(serviceIntent);
        }
    }
}
