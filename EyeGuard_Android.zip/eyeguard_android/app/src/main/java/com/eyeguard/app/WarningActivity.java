package com.eyeguard.app;

import android.content.Intent;
import android.os.Bundle;
import android.view.WindowManager;
import android.widget.Button;
import androidx.appcompat.app.AppCompatActivity;

public class WarningActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        // Hiện trên màn hình khóa
        getWindow().addFlags(
            WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON |
            WindowManager.LayoutParams.FLAG_SHOW_WHEN_LOCKED |
            WindowManager.LayoutParams.FLAG_TURN_SCREEN_ON
        );

        setContentView(R.layout.activity_warning);

        Button btnOk = findViewById(R.id.btnOk);
        btnOk.setOnClickListener(v -> {
            // Báo cho service reset countdown
            Intent intent = new Intent(this, EyeGuardService.class);
            intent.setAction("RESET");
            startService(intent);
            finish();
        });
    }
}
