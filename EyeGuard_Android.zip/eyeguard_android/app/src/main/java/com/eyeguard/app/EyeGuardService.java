package com.eyeguard.app;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import androidx.core.app.NotificationCompat;

public class EyeGuardService extends Service {

    private static final String CHANNEL_ID = "EyeGuardChannel";
    private static final int NOTIF_ID = 1;
    private static final int WARNING_SECONDS = 20 * 60; // 20 phút

    private Handler handler = new Handler(Looper.getMainLooper());
    private int secondsOn = 0;
    private boolean warningShown = false;

    // Receiver nhận sự kiện tắt/bật màn hình
    private BroadcastReceiver screenReceiver = new BroadcastReceiver() {
        @Override
        public void onReceive(Context context, String action) {
            onReceive(context, new Intent(action));
        }

        public void onReceive(Context context, Intent intent) {
            String action = intent.getAction();
            if (Intent.ACTION_SCREEN_OFF.equals(action)) {
                // Màn hình tắt → dừng đếm, reset
                stopCounting();
            } else if (Intent.ACTION_SCREEN_ON.equals(action)) {
                // Màn hình bật → bắt đầu đếm lại
                startCounting();
            }
        }
    };

    // Runnable đếm từng giây
    private Runnable countRunnable = new Runnable() {
        @Override
        public void run() {
            if (!warningShown) {
                secondsOn++;
                updateNotification();

                if (secondsOn >= WARNING_SECONDS) {
                    showWarning();
                } else {
                    handler.postDelayed(this, 1000);
                }
            }
        }
    };

    @Override
    public void onCreate() {
        super.onCreate();
        createNotificationChannel();

        // Đăng ký nhận sự kiện màn hình
        IntentFilter filter = new IntentFilter();
        filter.addAction(Intent.ACTION_SCREEN_ON);
        filter.addAction(Intent.ACTION_SCREEN_OFF);
        registerReceiver(screenReceiver, filter);

        // Bắt đầu đếm ngay khi service khởi động
        startCounting();
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        // Chạy foreground service với notification
        startForeground(NOTIF_ID, buildNotification("Đang bảo vệ mắt... 0:00"));
        return START_STICKY; // Tự khởi động lại nếu bị kill
    }

    private void startCounting() {
        secondsOn = 0;
        warningShown = false;
        handler.removeCallbacks(countRunnable);
        handler.postDelayed(countRunnable, 1000);
        updateNotification();
    }

    private void stopCounting() {
        secondsOn = 0;
        warningShown = false;
        handler.removeCallbacks(countRunnable);
        updateNotificationText("Màn hình tắt — Đã reset ✓");
    }

    private void showWarning() {
        warningShown = true;
        handler.removeCallbacks(countRunnable);

        // Hiện popup cảnh báo qua Activity
        Intent warningIntent = new Intent(this, WarningActivity.class);
        warningIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        startActivity(warningIntent);

        updateNotificationText("⚠️ Hãy nghỉ mắt!");
    }

    private void updateNotification() {
        int minutes = secondsOn / 60;
        int secs = secondsOn % 60;
        String time = String.format("%d:%02d", minutes, secs);
        updateNotificationText("Màn hình bật: " + time + " / 20:00");
    }

    private void updateNotificationText(String text) {
        NotificationManager nm = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
        nm.notify(NOTIF_ID, buildNotification(text));
    }

    private Notification buildNotification(String text) {
        Intent intent = new Intent(this, MainActivity.class);
        PendingIntent pi = PendingIntent.getActivity(this, 0, intent,
                PendingIntent.FLAG_IMMUTABLE);

        return new NotificationCompat.Builder(this, CHANNEL_ID)
                .setContentTitle("👁 Eye Guard")
                .setContentText(text)
                .setSmallIcon(android.R.drawable.ic_dialog_info)
                .setContentIntent(pi)
                .setPriority(NotificationCompat.PRIORITY_LOW)
                .setSilent(true)
                .build();
    }

    private void createNotificationChannel() {
        NotificationChannel channel = new NotificationChannel(
                CHANNEL_ID,
                "Eye Guard",
                NotificationManager.IMPORTANCE_LOW
        );
        channel.setDescription("Bảo vệ mắt");
        channel.setSound(null, null);
        NotificationManager nm = getSystemService(NotificationManager.class);
        nm.createNotificationChannel(channel);
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        handler.removeCallbacks(countRunnable);
        unregisterReceiver(screenReceiver);
    }

    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }
}
